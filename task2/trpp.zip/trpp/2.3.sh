#! /run/current-system/sw/bin/bash

# pushd and popd allow to enter a directory, do some scripts, and come back, wherever you were before
pushd ./ripgrep

# this builds ripgrep
cargo build --release

# this runs the executable, this seeks al occurances of the word `file` inside ~/system directory
./target/release/rg "file" ~/system

popd
