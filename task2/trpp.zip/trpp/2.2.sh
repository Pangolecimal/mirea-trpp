#! /run/current-system/sw/bin/bash

# I use direnv to autoload the project-specific shell specified by flake.nix and flake.lock
# But for the purposes of this script, i will disable it and use nix develop, which effectively
# does the same thing, but it is manual
direnv deny .

# This command spins up a new shell and invokes zsh while at it
# To escape it, use CTRL-D
nix develop --command zsh
