#! /run/current-system/sw/bin/bash

# I used ripgrep instead of the provided python package, because python is not real
# Ripgrep is written in Rust, thus its project config lies in Cargo.toml
# To parse it i used toml-cli, and Cargo.toml conveniently has all dependencies uder a single tag

# Raw one-line json deps
raw_json_deps=$(toml get ./ripgrep/Cargo.toml dependencies)
echo -e "$raw_json_deps\n"

# Then i used the jq command to prettify raw json output
pretty_json_deps=$(echo "" | jq)
echo "$raw_json_deps" | jq
